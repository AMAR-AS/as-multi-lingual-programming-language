# lexer.py
import re
from tokens import KEYWORDS

class Lexer:
    def __init__(self, code: str):
        self.code = code.splitlines()

    def tokenize(self):
        tokens = []
        for line in self.code:
            words = re.findall(r'[A-Za-z_][A-Za-z0-9_]*|".*?"|\d+|\S', line)
            for word in words:
                if word in KEYWORDS:
                    tokens.append((KEYWORDS[word], word))
                elif word.isdigit():
                    tokens.append(("INT", int(word)))
                elif word.startswith('"') and word.endswith('"'):
                    tokens.append(("STRING_LITERAL", word.strip('"')))
                else:
                    tokens.append(("IDENT", word))
        return tokens
