x = 10
msg = "Hello"

def greet(name):
    print(msg + " " + name)
    return True

greet("World")
