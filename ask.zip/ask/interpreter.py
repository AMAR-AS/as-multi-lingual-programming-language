# interpreter.py
import sys

def translate_to_python(code: str) -> str:
    replacements = {
        # data types
        "num ": "",
        "int ": "",
        "dec ": "",
        "float ": "",
        "txt ": "",
        "str ": "",
        "string ": "",
        "binary ": "",
        "bool ": "",
        "list ": "",     # ✅ FIX
        "array ": "",    # ✅ alias
        "dict ": "",     # ✅ FIX
        "map ": "",      # ✅ alias
        "none": "None",
        "null": "None",

        # booleans
        "true": "True",
        "false": "False",

        # functions
        "fcn ": "def ",
        "function ": "def ",
        "def ": "def ",
        "ret ": "return ",
        "goback ": "return ",

        # conditionals
        "if ": "if ",
        "check ": "if ",
        "orif ": "elif ",
        "elseif ": "elif ",
        "elif ": "elif ",
        "else ": "else ",

        # loops
        "for ": "for ",
        "let ": "for ",   # treat let as for
        "while ": "while ",
        "when ": "while ",
        "in ": "in ",
        "brk": "break",
        "break": "break",
        "exit": "break",
        "cont": "continue",
        "skip": "continue",

        # classes & objects
        "class ": "class ",
        "self": "self",
        "own": "self",

        # imports
        "import ": "import ",
        "include ": "import ",
        "from ": "from ",
        "as ": "as ",

        # exceptions
        "try": "try",
        "catch": "except",
        "except": "except",
        "finally": "finally",
        "cleanup": "finally",
        "raise": "raise",
        "throw": "raise",

        # misc
        "with ": "with ",
        "pass": "pass",
        "donothing": "pass",
        "leave": "pass",
        "del ": "del ",
        "delete ": "del ",
    }

    for k, v in replacements.items():
        code = code.replace(k, v)
    return code


def run_file(path):
    with open(path, "r") as f:
        code = f.read()

    py_code = translate_to_python(code)

    # run silently, only program output
    exec(py_code, {})


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python interpreter.py <file.as>")
    else:
        run_file(sys.argv[1])
